<?php

interface HtmlInterface {
    public function geraHtml();
}
