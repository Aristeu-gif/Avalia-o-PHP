<?php

require_once '../Controllers/logincontroller.class.php';

$loginController = new LoginController();

unset($loginController);
?>