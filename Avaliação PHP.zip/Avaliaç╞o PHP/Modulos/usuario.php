<?php

require_once '../Controllers/';

$matriculaController = new UsuarioController();

unset($matriculaController);
?>