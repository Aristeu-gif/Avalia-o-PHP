<?php

require_once '../Controllers/enderecocontroller.class.php';

$enderecoController = new EnderecoController();

unset($enderecoController);
?>