<?php

interface ModelInterface {

    public function checaAtributos();
}
